package com.jwt.jwtAutharization.controller;

import com.jwt.jwtAutharization.entites.UserEntity;
import com.jwt.jwtAutharization.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public List<UserEntity> getAllUser(){
        System.out.println("Getting request for access all users");
        return userService.getAllUser();
    }

    @PostMapping("/user")
    public UserEntity save(UserEntity user){
        return userService.saveList(user);
    }

    @GetMapping("/{username}")
    public UserEntity findByName(@PathVariable String name){
        return userService.getByUserName(name);
    }

}
