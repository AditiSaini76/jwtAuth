package com.jwt.jwtAutharization.dependencyInjection.spring;

public class Address {
}
