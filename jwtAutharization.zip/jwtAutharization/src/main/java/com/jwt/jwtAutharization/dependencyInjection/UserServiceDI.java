package com.jwt.jwtAutharization.dependencyInjection;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceDI {


    public List<String> getAllUser(){
        List<String> names = new ArrayList<>();
        names.add("Aditi"); names.add("Ankit");
        return names;
    }
}
