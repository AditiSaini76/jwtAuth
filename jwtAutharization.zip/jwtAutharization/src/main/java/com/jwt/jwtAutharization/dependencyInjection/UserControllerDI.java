package com.jwt.jwtAutharization.dependencyInjection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserControllerDI {
   @Autowired
   private UserServiceDI userServiceDi;


    // contructor injection
//    public UserController(UserService userService){
//        this.userService=userService;
//    }

    // because constructor injection is generally preferred for better immutability and testability of your components.

//    @RequestMapping(path = "/user" ,method = RequestMethod.GET)
    public List<String> getAllUser(){
       return   userServiceDi.getAllUser();
    }


}
