package com.jwt.jwtAutharization.dependencyInjection.spring;

public class Student {
    private String name;
    private int rollNo;
    private Address address;


    public void setAddress(Address address) {
        this.address = address;
    }

    public void setName(String name) {
        System.out.println("setter");
        this.name = name;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

//    public Student(){
//
//    }
//
//    public Student(String name, int rollNo) {
//        System.out.println("Using constructor injection");
//        this.name = name;
//        this.rollNo = rollNo;
//    }

    public void display(){
        System.out.println("Student name: -" +name);
        System.out.println("Student rollno:- " +rollNo);
    }
}


