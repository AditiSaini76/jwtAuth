package com.jwt.jwtAutharization.dependencyInjection;

public class AppConfig {
}
