package com.jwt.jwtAutharization.service;

import com.jwt.jwtAutharization.entites.UserEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

    List<UserEntity> dummyList = new ArrayList<>();

    public List<UserEntity> getAllUser(){
        return this.dummyList;
    }

    public UserEntity saveList(UserEntity user){
        dummyList.add(user);
        System.out.println("User save");
        return user;
    }

    public UserEntity getByUserName(String name){
       UserEntity user1 = dummyList.stream().filter((user)-> user.getName().equalsIgnoreCase(name)).findAny().get();
       return user1;
    }
}
