package com.jwt.jwtAutharization.dependencyInjection.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
        Student s = applicationContext.getBean("student" , Student.class);
        s.display();
//
//       Student s1 =  applicationContext.getBean("student1",Student.class);
//       s1.display();

    }
}
