package com.jwt.jwtAutharization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtAutharizationApplication {

	public static void main(String[] args) {

		SpringApplication.run(JwtAutharizationApplication.class, args);
	}

}
